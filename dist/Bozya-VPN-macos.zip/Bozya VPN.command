#!/bin/bash
cd "$(dirname "$0")"
if [ "$(uname -m)" = "arm64" ]; then
  exec "./Bozya-VPN-arm64"
else
  exec "./Bozya-VPN-intel"
fi
