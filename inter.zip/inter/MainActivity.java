package com.deepseek.chat;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.appcompat.app.a;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import com.deepseek.chat.ui.pages.table.TablePreviewActivity;
import defpackage.a7b;
import defpackage.cg8;
import defpackage.cn2;
import defpackage.cq0;
import defpackage.dcc;
import defpackage.dw;
import defpackage.ez7;
import defpackage.f10;
import defpackage.fd3;
import defpackage.g43;
import defpackage.hy9;
import defpackage.id6;
import defpackage.ip3;
import defpackage.jd6;
import defpackage.jd8;
import defpackage.k91;
import defpackage.kd6;
import defpackage.lq2;
import defpackage.m5c;
import defpackage.mc7;
import defpackage.nla;
import defpackage.ny;
import defpackage.op2;
import defpackage.peb;
import defpackage.qb9;
import defpackage.qj2;
import defpackage.s13;
import defpackage.sp2;
import defpackage.ss;
import defpackage.tm9;
import defpackage.tyb;
import defpackage.v76;
import defpackage.vj4;
import defpackage.vm2;
import defpackage.vx5;
import defpackage.w57;
import defpackage.wq3;
import defpackage.wv2;
import defpackage.x29;
import defpackage.x6b;
import defpackage.xp0;
import defpackage.y6b;
import defpackage.y94;
import defpackage.yg4;
import defpackage.z46;
import defpackage.z6b;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/* compiled from: r8-map-id-a7bb329143d8433c85843ce5c333b62cc095bf0c457acd5814e95311f0a086ce */
/* loaded from: classes.dex */
public final class MainActivity extends ss {
    public static final /* synthetic */ int D = 0;
    public final vx5 B = nla.A(1, new kd6(this, 0));
    public final vx5 C = nla.A(1, new kd6(this, 1));

    /* JADX WARN: Code restructure failed: missing block: B:23:0x007e, code lost:
    
        if (r1 != null) goto L31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0080, code lost:
    
        android.os.StrictMode.setThreadPolicy(r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x008c, code lost:
    
        if (r1 == null) goto L32;
     */
    /* JADX WARN: Removed duplicated region for block: B:20:0x004d A[Catch: all -> 0x0077, Exception -> 0x0079, LOOP:0: B:18:0x0047->B:20:0x004d, LOOP_END, TryCatch #2 {all -> 0x0077, blocks: (B:17:0x003e, B:18:0x0047, B:20:0x004d, B:22:0x007b, B:30:0x0085), top: B:16:0x003e, outer: #0, inners: #1 }] */
    @Override // defpackage.ss, android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void attachBaseContext(android.content.Context r8) {
        /*
            r7 = this;
            super.attachBaseContext(r8)
            java.util.concurrent.atomic.AtomicReference r8 = defpackage.qm9.e
            java.lang.Object r8 = r8.get()
            qm9 r8 = (defpackage.qm9) r8
            if (r8 != 0) goto L1f
            android.content.Context r8 = r7.getApplicationContext()
            r0 = 0
            if (r8 == 0) goto L1b
            android.content.Context r8 = r7.getApplicationContext()
            defpackage.qm9.d(r8, r0)
        L1b:
            defpackage.qm9.d(r7, r0)
            return
        L1f:
            scb r0 = r8.d
            java.util.HashSet r8 = r8.a()
            monitor-enter(r0)
            android.os.StrictMode$ThreadPolicy r1 = android.os.StrictMode.getThreadPolicy()     // Catch: java.lang.Throwable -> L31 java.lang.Exception -> L35
            android.os.StrictMode.allowThreadDiskReads()     // Catch: java.lang.Throwable -> L31 java.lang.Exception -> L33
            android.os.StrictMode.allowThreadDiskWrites()     // Catch: java.lang.Throwable -> L31 java.lang.Exception -> L33
            goto L3e
        L31:
            r7 = move-exception
            goto L97
        L33:
            r2 = move-exception
            goto L37
        L35:
            r2 = move-exception
            r1 = 0
        L37:
            java.lang.String r3 = "SplitCompat"
            java.lang.String r4 = "Unable to set up strict mode."
            android.util.Log.i(r3, r4, r2)     // Catch: java.lang.Throwable -> L31
        L3e:
            java.util.HashSet r2 = new java.util.HashSet     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            r2.<init>()     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            java.util.Iterator r8 = r8.iterator()     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
        L47:
            boolean r3 = r8.hasNext()     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            if (r3 == 0) goto L7b
            java.lang.Object r3 = r8.next()     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            java.lang.String r3 = (java.lang.String) r3     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            java.lang.Object r4 = r0.a     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            fxb r4 = (defpackage.fxb) r4     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            java.io.File r5 = new java.io.File     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            java.io.File r4 = r4.x()     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            java.lang.String r6 = "verified-splits"
            r5.<init>(r4, r6)     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            defpackage.fxb.v(r5)     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            java.lang.String r3 = java.lang.String.valueOf(r3)     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            java.lang.String r4 = ".apk"
            java.lang.String r3 = r3.concat(r4)     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            java.io.File r3 = defpackage.fxb.u(r5, r3)     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            r2.add(r3)     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            goto L47
        L77:
            r7 = move-exception
            goto L90
        L79:
            r7 = move-exception
            goto L85
        L7b:
            r0.v(r7, r2)     // Catch: java.lang.Throwable -> L77 java.lang.Exception -> L79
            if (r1 == 0) goto L83
        L80:
            android.os.StrictMode.setThreadPolicy(r1)     // Catch: java.lang.Throwable -> L31
        L83:
            monitor-exit(r0)
            goto L8f
        L85:
            java.lang.String r8 = "SplitCompat"
            java.lang.String r2 = "Error installing additional splits"
            android.util.Log.e(r8, r2, r7)     // Catch: java.lang.Throwable -> L77
            if (r1 == 0) goto L83
            goto L80
        L8f:
            return
        L90:
            if (r1 != 0) goto L93
            goto L96
        L93:
            android.os.StrictMode.setThreadPolicy(r1)     // Catch: java.lang.Throwable -> L31
        L96:
            throw r7     // Catch: java.lang.Throwable -> L31
        L97:
            monitor-exit(r0)     // Catch: java.lang.Throwable -> L31
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.deepseek.chat.MainActivity.attachBaseContext(android.content.Context):void");
    }

    @Override // defpackage.ss, defpackage.tm2, android.app.Activity, android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        s13 s13Var;
        k91 k91Var = (k91) this.C.getValue();
        k91Var.getClass();
        if ((keyEvent.getKeyCode() != 25 && keyEvent.getKeyCode() != 24) || (s13Var = k91Var.a) == null) {
            return super.dispatchKeyEvent(keyEvent);
        }
        if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
            s13Var.v();
            return true;
        }
        return true;
    }

    @Override // defpackage.ss, defpackage.um2, android.app.Activity, android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        u();
        ((y94) this.B.getValue()).d(this);
    }

    @Override // defpackage.fc4, defpackage.um2, defpackage.tm2, android.app.Activity
    public final void onCreate(Bundle bundle) {
        peb pebVar;
        String str;
        Locale a;
        super.onCreate(bundle);
        byte b = 0;
        int i = 1;
        if (Build.VERSION.SDK_INT < 33 && (a = dw.a(((ny) ((ez7) w57.y(this).c(cg8.a.b(ez7.class), null, null)).c.getValue()).b)) != null) {
            a.k(v76.a(a));
        }
        ((y94) this.B.getValue()).d(this);
        Context applicationContext = getApplicationContext();
        synchronized (dcc.class) {
            try {
                if (dcc.a == null) {
                    Context applicationContext2 = applicationContext.getApplicationContext();
                    if (applicationContext2 != null) {
                        applicationContext = applicationContext2;
                    }
                    dcc.a = new peb(new wq3(applicationContext, 1));
                }
                pebVar = dcc.a;
            } catch (Throwable th) {
                throw th;
            }
        }
        tm9 tm9Var = (tm9) ((m5c) pebVar.b).mo35d();
        Set b2 = tm9Var.b();
        v76 b3 = a.b();
        z46 H = f10.H();
        int size = b3.a.size();
        if (size >= 0) {
            int i2 = 0;
            while (true) {
                Locale locale = b3.a.get(i2);
                if (locale != null) {
                    str = locale.getLanguage();
                } else {
                    str = null;
                }
                H.add(str);
                if (i2 == size) {
                    break;
                } else {
                    i2++;
                }
            }
        }
        List d1 = qj2.d1(qj2.K0(qj2.N0(f10.C(H))), b2);
        if (!d1.isEmpty()) {
            mc7 mc7Var = new mc7(7);
            Iterator it = d1.iterator();
            while (it.hasNext()) {
                ((ArrayList) mc7Var.c).add(Locale.forLanguageTag((String) it.next()));
            }
            tm9Var.a(new x29(mc7Var));
        }
        ip3.a(this, new hy9(0, 0, new qb9(26)));
        u();
        vm2.a(this, new cn2(new id6(this, i, b), true, 1837541827));
        t(getIntent());
    }

    @Override // defpackage.um2, android.app.Activity
    public final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        t(intent);
    }

    @Override // defpackage.fc4, android.app.Activity
    public final void onResume() {
        super.onResume();
        if (TablePreviewActivity.Y) {
            TablePreviewActivity.Y = false;
        } else {
            overridePendingTransition(0, R.anim.fade_out);
        }
        ((y94) this.B.getValue()).d(this);
        u();
    }

    public final void s(int i, vj4 vj4Var) {
        int i2;
        boolean z;
        MainActivity mainActivity;
        Object jd6Var;
        vj4Var.i0(-2122918778);
        if (vj4Var.h(this)) {
            i2 = 4;
        } else {
            i2 = 2;
        }
        int i3 = i2 | i;
        if ((i3 & 3) != 2) {
            z = true;
        } else {
            z = false;
        }
        if (vj4Var.X(i3 & 1, z)) {
            if (sp2.d()) {
                sp2.f("com.deepseek.chat.MainActivity.FitStatusBarColor (MainActivity.kt:83)");
            }
            View view = (View) vj4Var.j(AndroidCompositionLocals_androidKt.f);
            boolean a = g43.a(((g43) vj4Var.j(lq2.a)).a, vj4Var);
            int i4 = ((Configuration) vj4Var.j(AndroidCompositionLocals_androidKt.a)).uiMode;
            Boolean valueOf = Boolean.valueOf(a);
            Window window = getWindow();
            Integer valueOf2 = Integer.valueOf(i4);
            boolean h = vj4Var.h(this) | vj4Var.h(view) | vj4Var.g(a);
            Object S = vj4Var.S();
            if (!h && S != op2.a) {
                jd6Var = S;
                mainActivity = this;
            } else {
                mainActivity = this;
                jd6Var = new jd6(mainActivity, view, a, null, 0);
                vj4Var.q0(jd6Var);
            }
            wv2.v(valueOf, window, valueOf2, (yg4) jd6Var, vj4Var);
            if (sp2.d()) {
                sp2.e();
            }
        } else {
            mainActivity = this;
            vj4Var.a0();
        }
        jd8 v = vj4Var.v();
        if (v != null) {
            v.d = new id6(mainActivity, i);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:103:0x01dd  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0212  */
    /* JADX WARN: Removed duplicated region for block: B:56:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void t(android.content.Intent r15) {
        /*
            Method dump skipped, instructions count: 534
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.deepseek.chat.MainActivity.t(android.content.Intent):void");
    }

    public final void u() {
        a7b a7bVar;
        int i;
        y6b.a.getClass();
        z6b z6bVar = x6b.b;
        z6bVar.getClass();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 34) {
            a7bVar = fd3.b;
        } else if (i2 >= 30) {
            a7bVar = cq0.b;
        } else {
            a7bVar = tyb.A;
        }
        xp0 xp0Var = a7bVar.c(this, z6bVar.b).a;
        int width = xp0Var.c().width();
        int height = xp0Var.c().height();
        float max = Math.max(width, height) / Math.min(width, height);
        int i3 = getResources().getConfiguration().smallestScreenWidthDp;
        if (max >= 1.75f && i3 < 600) {
            i = 1;
        } else {
            i = 13;
        }
        setRequestedOrientation(i);
    }
}
