package com.deepseek.chat.ui.model

import java.util.UUID

/**
 * Модели данных главного экрана чата DeepSeek.
 */
enum class DeepSeekModel(val displayName: String, val description: String) {
    DEEPSEEK_V3("DeepSeek-V3", "Стандартная быстрая модель"),
    DEEPSEEK_R1("DeepSeek-R1", "Модель с глубоким рассуждением (DeepThink)")
}

enum class MessageSender {
    USER,
    ASSISTANT
}

data class ThinkingProcess(
    val reasoningText: String,
    val durationSeconds: Int = 0,
    val isExpanded: Boolean = true,
    val isFinished: Boolean = true
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: MessageSender,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val thinkingProcess: ThinkingProcess? = null,
    val isStreaming: Boolean = false,
    val isSearchEnabled: Boolean = false
)

data class ChatUiState(
    val currentModel: DeepSeekModel = DeepSeekModel.DEEPSEEK_V3,
    val isDeepThinkActive: Boolean = false,
    val isWebSearchActive: Boolean = false,
    val inputText: String = "",
    val isGenerating: Boolean = false,
    val messages: List<ChatMessage> = emptyList()
)
