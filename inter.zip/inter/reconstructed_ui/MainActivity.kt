package com.deepseek.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.deepseek.chat.ui.screen.DeepSeekChatScreen
import com.deepseek.chat.ui.theme.DeepSeekTheme

/**
 * Чистая деобфусцированная точка входа приложения DeepSeek.
 * Заменяет оригинальную обфусцированную MainActivity.java со всеми битыми R8-методами.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            DeepSeekTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    DeepSeekChatScreen(
                        onOpenDrawer = {
                            // Открытие боковой панели истории диалогов
                        }
                    )
                }
            }
        }
    }
}
