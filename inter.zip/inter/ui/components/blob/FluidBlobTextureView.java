package com.deepseek.chat.ui.components.blob;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.opengl.EGL14;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.view.MotionEvent;
import android.view.TextureView;
import cn.fly.verify.BuildConfig;
import com.ishumei.smantifraud.l111l111lIlll;
import com.ishumei.smantifraud.l11l111lI1l;
import com.ishumei.smantifraud.l1l11I11l;
import defpackage.a99;
import defpackage.c54;
import defpackage.dj2;
import defpackage.e64;
import defpackage.gk7;
import defpackage.h64;
import defpackage.hu1;
import defpackage.ig4;
import defpackage.j54;
import defpackage.kg4;
import defpackage.kg9;
import defpackage.m54;
import defpackage.mg3;
import defpackage.n54;
import defpackage.p0;
import defpackage.p54;
import defpackage.qh;
import defpackage.sz0;
import defpackage.uw6;
import defpackage.w5;
import defpackage.x33;
import defpackage.xq;
import defpackage.yg4;
import defpackage.z52;
import defpackage.z8b;
import defpackage.zc5;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicLong;
import kotlin.Metadata;

/* compiled from: r8-map-id-a7bb329143d8433c85843ce5c333b62cc095bf0c457acd5814e95311f0a086ce */
@Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0019\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u0007\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u00012\u00020\u0002:\u0001OR.\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u00038\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000bR(\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00050\r8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u000e\u0010\u000f\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R6\u0010\u001d\u001a\u0016\u0012\u0004\u0012\u00020\u0004\u0012\u0006\u0012\u0004\u0018\u00010\u0016\u0012\u0004\u0012\u00020\u00050\u00158\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0017\u0010\u0018\u001a\u0004\b\u0019\u0010\u001a\"\u0004\b\u001b\u0010\u001cR\"\u0010!\u001a\u00020\u001e8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u001f\u0010 \u001a\u0004\b!\u0010\"\"\u0004\b#\u0010$R*\u0010-\u001a\u00020%2\u0006\u0010&\u001a\u00020%8\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\b'\u0010(\u001a\u0004\b)\u0010*\"\u0004\b+\u0010,R*\u00101\u001a\u00020\u001e2\u0006\u0010&\u001a\u00020\u001e8\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\b.\u0010 \u001a\u0004\b/\u0010\"\"\u0004\b0\u0010$R*\u00103\u001a\u00020\u001e2\u0006\u0010&\u001a\u00020\u001e8\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\b2\u0010 \u001a\u0004\b3\u0010\"\"\u0004\b4\u0010$R\"\u0010;\u001a\u00020\u00048\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b5\u00106\u001a\u0004\b7\u00108\"\u0004\b9\u0010:R*\u0010=\u001a\u00020\u001e2\u0006\u0010&\u001a\u00020\u001e8\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\b<\u0010 \u001a\u0004\b=\u0010\"\"\u0004\b>\u0010$R.\u0010F\u001a\u0004\u0018\u00010?2\b\u0010&\u001a\u0004\u0018\u00010?8\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\b@\u0010A\u001a\u0004\bB\u0010C\"\u0004\bD\u0010ER\"\u0010J\u001a\u00020\u00048\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bG\u00106\u001a\u0004\bH\u00108\"\u0004\bI\u0010:R\u0014\u0010N\u001a\u00020K8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\bL\u0010M¨\u0006P"}, d2 = {"Lcom/deepseek/chat/ui/components/blob/FluidBlobTextureView;", "Landroid/view/TextureView;", "Landroid/view/TextureView$SurfaceTextureListener;", "Lkotlin/Function1;", BuildConfig.FLAVOR, "Ljna;", l1l11I11l.l111l1111lIl, "Lkg4;", "getOnFramePresented", "()Lkg4;", "setOnFramePresented", "(Lkg4;)V", "onFramePresented", "Lkotlin/Function0;", "f", "Lig4;", "getOnFrameUpdated", "()Lig4;", "setOnFrameUpdated", "(Lig4;)V", "onFrameUpdated", "Lkotlin/Function2;", "Landroid/graphics/Bitmap;", "h", "Lyg4;", "getOnPauseSnapshotReady", "()Lyg4;", "setOnPauseSnapshotReady", "(Lyg4;)V", "onPauseSnapshotReady", BuildConfig.FLAVOR, "n", "Z", "isDisposed", "()Z", "setDisposed", "(Z)V", "Ln54;", "value", "o", "Ln54;", "getRenderMode", "()Ln54;", "setRenderMode", "(Ln54;)V", "renderMode", "p", "getCapturePauseSnapshot", "setCapturePauseSnapshot", "capturePauseSnapshot", "q", "isCoveredByPauseSnapshot", "setCoveredByPauseSnapshot", "r", "J", "getPauseSnapshotGeneration", "()J", "setPauseSnapshotGeneration", "(J)V", "pauseSnapshotGeneration", l111l111lIlll.l11l111l1Il, "isPaused", "setPaused", "Lj54;", "t", "Lj54;", "getPauseController", "()Lj54;", "setPauseController", "(Lj54;)V", "pauseController", "D", "getFrameRequestId", "setFrameRequestId", "frameRequestId", BuildConfig.FLAVOR, "getResolutionScale", "()F", "resolutionScale", "h64", "app"}, k = 1, mv = {2, 3, 0}, xi = gk7.h)
/* loaded from: classes.dex */
public final class FluidBlobTextureView extends TextureView implements TextureView.SurfaceTextureListener {
    public static final /* synthetic */ int P0 = 0;
    public final AtomicLong A;
    public final AtomicLong B;
    public final AtomicLong C;

    /* renamed from: D, reason: from kotlin metadata */
    public volatile long frameRequestId;
    public long E;
    public long K0;
    public int L0;
    public int M0;
    public int N0;
    public int O0;
    public final c54 a;
    public final a99 b;
    public final z52 c;
    public final qh d;

    /* renamed from: e, reason: from kotlin metadata */
    public kg4 onFramePresented;

    /* renamed from: f, reason: from kotlin metadata */
    public ig4 onFrameUpdated;
    public final p54 g;

    /* renamed from: h, reason: from kotlin metadata */
    public yg4 onPauseSnapshotReady;
    public final Handler i;
    public volatile int j;
    public volatile int k;
    public volatile HandlerThread l;
    public volatile h64 m;

    /* renamed from: n, reason: from kotlin metadata */
    public volatile boolean isDisposed;

    /* renamed from: o, reason: from kotlin metadata */
    public volatile n54 renderMode;

    /* renamed from: p, reason: from kotlin metadata */
    public volatile boolean capturePauseSnapshot;

    /* renamed from: q, reason: from kotlin metadata */
    public boolean isCoveredByPauseSnapshot;

    /* renamed from: r, reason: from kotlin metadata */
    public volatile long pauseSnapshotGeneration;

    /* renamed from: s, reason: from kotlin metadata */
    public volatile boolean isPaused;

    /* renamed from: t, reason: from kotlin metadata */
    public volatile j54 pauseController;
    public x33 u;
    public volatile boolean v;
    public volatile boolean w;
    public volatile boolean x;
    public volatile boolean y;
    public volatile int z;

    public FluidBlobTextureView(Context context, c54 c54Var, a99 a99Var, z52 z52Var, qh qhVar, kg4 kg4Var, w5 w5Var, p54 p54Var, xq xqVar) {
        super(context);
        this.a = c54Var;
        this.b = a99Var;
        this.c = z52Var;
        this.d = qhVar;
        this.onFramePresented = kg4Var;
        this.onFrameUpdated = w5Var;
        this.g = p54Var;
        this.onPauseSnapshotReady = xqVar;
        this.i = new Handler(Looper.getMainLooper());
        this.renderMode = n54.b;
        this.y = true;
        this.A = new AtomicLong(0L);
        this.B = new AtomicLong(0L);
        this.C = new AtomicLong(0L);
        this.E = Long.MIN_VALUE;
        setOpaque(false);
        setAlpha(l11l111lI1l.l111l1111lI1l);
        setClickable(false);
        setFocusable(false);
        setOutlineProvider(new mg3(1));
        setClipToOutline(true);
        setSurfaceTextureListener(this);
    }

    public static final Bitmap a(FluidBlobTextureView fluidBlobTextureView) {
        int i;
        int i2;
        int resolutionScale = (int) (fluidBlobTextureView.j * fluidBlobTextureView.getResolutionScale());
        if (resolutionScale < 1) {
            i = 1;
        } else {
            i = resolutionScale;
        }
        int resolutionScale2 = (int) (fluidBlobTextureView.k * fluidBlobTextureView.getResolutionScale());
        if (resolutionScale2 < 1) {
            i2 = 1;
        } else {
            i2 = resolutionScale2;
        }
        Bitmap bitmap = null;
        if (fluidBlobTextureView.j > 0 && fluidBlobTextureView.k > 0 && fluidBlobTextureView.a.j && fluidBlobTextureView.e(i, i2)) {
            GLES20.glBindFramebuffer(36160, fluidBlobTextureView.L0);
            c54 c54Var = fluidBlobTextureView.a;
            c54Var.getClass();
            GLES20.glViewport(0, 0, i, i2);
            c54Var.n = i;
            c54Var.o = i2;
            fluidBlobTextureView.a.c();
            ByteBuffer order = ByteBuffer.allocateDirect(i * i2 * 4).order(ByteOrder.nativeOrder());
            order.position(0);
            GLES20.glReadPixels(0, 0, i, i2, 6408, 5121, order);
            int glGetError = GLES20.glGetError();
            if (glGetError != 0) {
                z8b.p0("FluidBlobTextureView", uw6.s(glGetError, "pause snapshot glReadPixels failed: "));
            } else {
                order.rewind();
                Bitmap createBitmap = Bitmap.createBitmap(i, i2, Bitmap.Config.ARGB_8888);
                createBitmap.setPremultiplied(true);
                createBitmap.copyPixelsFromBuffer(order);
                Matrix matrix = new Matrix();
                matrix.postScale(1.0f, -1.0f, i / 2.0f, i2 / 2.0f);
                int i3 = i2;
                int i4 = i;
                bitmap = Bitmap.createBitmap(createBitmap, 0, 0, i4, i3, matrix, false);
                i = i4;
                i2 = i3;
                if (bitmap != createBitmap) {
                    createBitmap.recycle();
                }
            }
            GLES20.glBindFramebuffer(36160, 0);
            c54 c54Var2 = fluidBlobTextureView.a;
            c54Var2.getClass();
            GLES20.glViewport(0, 0, i, i2);
            c54Var2.n = i;
            c54Var2.o = i2;
        }
        return bitmap;
    }

    public static final boolean b(FluidBlobTextureView fluidBlobTextureView, EGLDisplay eGLDisplay, EGLSurface eGLSurface) {
        if (eGLDisplay != null && eGLSurface != null && fluidBlobTextureView.j > 0 && fluidBlobTextureView.k > 0) {
            if (!fluidBlobTextureView.a.j) {
                if (!fluidBlobTextureView.x) {
                    fluidBlobTextureView.x = true;
                    fluidBlobTextureView.i.post(new e64(0, fluidBlobTextureView));
                    return false;
                }
            } else {
                long j = fluidBlobTextureView.frameRequestId;
                fluidBlobTextureView.a.c();
                boolean eglSwapBuffers = EGL14.eglSwapBuffers(eGLDisplay, eGLSurface);
                if (eglSwapBuffers) {
                    fluidBlobTextureView.A.set(j);
                    fluidBlobTextureView.w = true;
                    return eglSwapBuffers;
                }
                int eglGetError = EGL14.eglGetError();
                if (eglGetError != 12288) {
                    z8b.p0("FluidBlobTextureView", uw6.s(eglGetError, "eglSwapBuffers error: "));
                    if (!fluidBlobTextureView.x) {
                        fluidBlobTextureView.x = true;
                        fluidBlobTextureView.i.post(new e64(0, fluidBlobTextureView));
                    }
                }
                return eglSwapBuffers;
            }
        }
        return false;
    }

    public static final void d(FluidBlobTextureView fluidBlobTextureView) {
        h64 h64Var = fluidBlobTextureView.m;
        if (h64Var == null || fluidBlobTextureView.isDisposed) {
            return;
        }
        fluidBlobTextureView.i.post(new sz0(fluidBlobTextureView, fluidBlobTextureView.z, h64Var, 7));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final float getResolutionScale() {
        kg9.B(this.b);
        return 1.0f;
    }

    @Override // android.view.View
    public final boolean dispatchTouchEvent(MotionEvent motionEvent) {
        return false;
    }

    public final boolean e(int i, int i2) {
        boolean z = true;
        if (this.L0 != 0 && this.M0 != 0 && this.N0 == i && this.O0 == i2) {
            return true;
        }
        g();
        int[] iArr = new int[1];
        int[] iArr2 = new int[1];
        GLES20.glGenFramebuffers(1, iArr, 0);
        GLES20.glGenTextures(1, iArr2, 0);
        this.L0 = iArr[0];
        int i3 = iArr2[0];
        this.M0 = i3;
        this.N0 = i;
        this.O0 = i2;
        GLES20.glBindTexture(3553, i3);
        GLES20.glTexParameteri(3553, 10241, 9729);
        GLES20.glTexParameteri(3553, 10240, 9729);
        GLES20.glTexParameteri(3553, 10242, 33071);
        GLES20.glTexParameteri(3553, 10243, 33071);
        GLES20.glTexImage2D(3553, 0, 6408, i, i2, 0, 6408, 5121, null);
        GLES20.glBindFramebuffer(36160, this.L0);
        GLES20.glFramebufferTexture2D(36160, 36064, 3553, this.M0, 0);
        if (GLES20.glCheckFramebufferStatus(36160) != 36053) {
            z = false;
        }
        GLES20.glBindFramebuffer(36160, 0);
        GLES20.glBindTexture(3553, 0);
        if (!z) {
            g();
        }
        return z;
    }

    public final boolean f() {
        j54 j54Var;
        if (this.isPaused || ((j54Var = this.pauseController) != null && j54Var.a)) {
            return true;
        }
        return false;
    }

    public final void g() {
        int i = this.M0;
        if (i != 0) {
            GLES20.glDeleteTextures(1, new int[]{i}, 0);
            this.M0 = 0;
        }
        int i2 = this.L0;
        if (i2 != 0) {
            GLES20.glDeleteFramebuffers(1, new int[]{i2}, 0);
            this.L0 = 0;
        }
        this.N0 = 0;
        this.O0 = 0;
    }

    public final boolean getCapturePauseSnapshot() {
        return this.capturePauseSnapshot;
    }

    public final long getFrameRequestId() {
        return this.frameRequestId;
    }

    public final kg4 getOnFramePresented() {
        return this.onFramePresented;
    }

    public final ig4 getOnFrameUpdated() {
        return this.onFrameUpdated;
    }

    public final yg4 getOnPauseSnapshotReady() {
        return this.onPauseSnapshotReady;
    }

    public final j54 getPauseController() {
        return this.pauseController;
    }

    public final long getPauseSnapshotGeneration() {
        return this.pauseSnapshotGeneration;
    }

    public final n54 getRenderMode() {
        return this.renderMode;
    }

    public final void h() {
        this.y = true;
        h64 h64Var = this.m;
        if (h64Var != null) {
            h64Var.sendEmptyMessage(5);
        }
    }

    public final void i() {
        if (this.capturePauseSnapshot && !(this.renderMode instanceof m54) && !this.isDisposed) {
            this.C.set(this.pauseSnapshotGeneration);
            this.B.incrementAndGet();
            h64 h64Var = this.m;
            if (h64Var != null) {
                h64Var.sendEmptyMessage(6);
            }
        }
    }

    public final void j() {
        HandlerThread handlerThread;
        h64 h64Var = this.m;
        if (h64Var == null || (handlerThread = this.l) == null) {
            return;
        }
        this.m = null;
        h64Var.removeCallbacksAndMessages(null);
        h64Var.sendMessageAtFrontOfQueue(h64Var.obtainMessage(7));
        try {
            handlerThread.join();
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
        this.l = null;
    }

    public final void k() {
        dj2 dj2Var = new dj2(14, this);
        if (zc5.b(Looper.myLooper(), Looper.getMainLooper())) {
            dj2Var.v();
        } else {
            this.i.post(new p0(29, dj2Var));
        }
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
        Message obtainMessage;
        this.isDisposed = false;
        this.a.h = false;
        this.v = false;
        this.w = false;
        this.x = false;
        this.y = true;
        this.A.set(this.frameRequestId);
        this.B.set(0L);
        this.C.set(0L);
        this.K0 = 0L;
        this.E = Long.MIN_VALUE;
        this.z++;
        setAlpha(l11l111lI1l.l111l1111lI1l);
        this.d.h(Boolean.TRUE);
        this.j = i;
        this.k = i2;
        invalidateOutline();
        int resolutionScale = (int) (i * getResolutionScale());
        if (resolutionScale < 1) {
            resolutionScale = 1;
        }
        int resolutionScale2 = (int) (i2 * getResolutionScale());
        if (resolutionScale2 < 1) {
            resolutionScale2 = 1;
        }
        surfaceTexture.setDefaultBufferSize(resolutionScale, resolutionScale2);
        z8b.S("FluidBlobTextureView", "Surface available " + i + "x" + i2 + " (scaled " + resolutionScale + "x" + resolutionScale2 + ")");
        if (this.l == null) {
            HandlerThread handlerThread = new HandlerThread("FluidBlob-GL-Thread");
            handlerThread.start();
            this.m = new h64(this, handlerThread.getLooper());
            this.l = handlerThread;
            h64 h64Var = this.m;
            if (h64Var != null && (obtainMessage = h64Var.obtainMessage(1, surfaceTexture)) != null) {
                obtainMessage.sendToTarget();
            }
        }
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        z8b.S("FluidBlobTextureView", "Surface destroyed — stopping render thread");
        this.isDisposed = true;
        this.z++;
        this.d.h(Boolean.TRUE);
        j();
        return true;
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
        Message obtainMessage;
        this.j = i;
        this.k = i2;
        invalidateOutline();
        int resolutionScale = (int) (i * getResolutionScale());
        int i3 = 1;
        if (resolutionScale < 1) {
            resolutionScale = 1;
        }
        int resolutionScale2 = (int) (i2 * getResolutionScale());
        if (resolutionScale2 >= 1) {
            i3 = resolutionScale2;
        }
        surfaceTexture.setDefaultBufferSize(resolutionScale, i3);
        h64 h64Var = this.m;
        if (h64Var != null && (obtainMessage = h64Var.obtainMessage(2, resolutionScale, i3, surfaceTexture)) != null) {
            obtainMessage.sendToTarget();
        }
        h();
    }

    @Override // android.view.TextureView.SurfaceTextureListener
    public final void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        this.onFrameUpdated.v();
        if (!this.v && this.w && !this.isDisposed) {
            this.v = true;
            setAlpha(1.0f);
            this.d.h(Boolean.FALSE);
        }
        long j = this.A.get();
        if (j != this.E && !this.isDisposed) {
            this.E = j;
            this.onFramePresented.h(Long.valueOf(j));
        }
    }

    public final void setCapturePauseSnapshot(boolean z) {
        if (this.capturePauseSnapshot != z) {
            this.capturePauseSnapshot = z;
            if (z && f()) {
                i();
            }
        }
    }

    public final void setCoveredByPauseSnapshot(boolean z) {
        if (this.isCoveredByPauseSnapshot == z) {
            return;
        }
        this.isCoveredByPauseSnapshot = z;
        k();
    }

    public final void setDisposed(boolean z) {
        this.isDisposed = z;
    }

    public final void setFrameRequestId(long j) {
        this.frameRequestId = j;
    }

    public final void setOnFramePresented(kg4 kg4Var) {
        this.onFramePresented = kg4Var;
    }

    public final void setOnFrameUpdated(ig4 ig4Var) {
        this.onFrameUpdated = ig4Var;
    }

    public final void setOnPauseSnapshotReady(yg4 yg4Var) {
        this.onPauseSnapshotReady = yg4Var;
    }

    public final void setPauseController(j54 j54Var) {
        x33 x33Var;
        if (this.pauseController != j54Var) {
            x33 x33Var2 = this.u;
            if (x33Var2 != null) {
                x33Var2.v();
            }
            this.pauseController = j54Var;
            if (j54Var != null) {
                hu1 hu1Var = new hu1(22, this);
                j54Var.b.add(hu1Var);
                x33Var = new x33(4, j54Var, hu1Var);
            } else {
                x33Var = null;
            }
            this.u = x33Var;
            if (j54Var == null || !j54Var.a) {
                h();
            }
            if (j54Var != null && j54Var.a) {
                i();
            }
        }
    }

    public final void setPauseSnapshotGeneration(long j) {
        this.pauseSnapshotGeneration = j;
    }

    public final void setPaused(boolean z) {
        if (this.isPaused != z) {
            boolean z2 = this.isPaused;
            this.isPaused = z;
            if (!z2 && z) {
                i();
            } else if (z2 && !z) {
                setCoveredByPauseSnapshot(false);
                h();
            }
        }
    }

    public final void setRenderMode(n54 n54Var) {
        if (zc5.b(this.renderMode, n54Var)) {
            return;
        }
        this.renderMode = n54Var;
        k();
        h();
    }
}
