package com.deepseek.chat.ui.components.textfield;

import android.graphics.Rect;
import android.os.Build;
import android.text.Editable;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.InputMethodManager;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.widget.AppCompatEditText;
import cn.fly.verify.BuildConfig;
import defpackage.dj2;
import defpackage.ey9;
import defpackage.gk7;
import defpackage.mv7;
import defpackage.nb5;
import defpackage.xa;
import defpackage.z23;
import defpackage.zb;
import kotlin.Metadata;

/* compiled from: r8-map-id-a7bb329143d8433c85843ce5c333b62cc095bf0c457acd5814e95311f0a086ce */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0019R\u001d\u0010\u0007\u001a\u0004\u0018\u00010\u00028BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u0003\u0010\u0004\u001a\u0004\b\u0005\u0010\u0006R\"\u0010\u000f\u001a\u00020\b8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\t\u0010\n\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u001b\u0010\u0014\u001a\u00020\u00108BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u0011\u0010\u0004\u001a\u0004\b\u0012\u0010\u0013R\u0013\u0010\u0018\u001a\u0004\u0018\u00010\u00158F¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\u001c\u001a\u00020\u00198F¢\u0006\u0006\u001a\u0004\b\u001a\u0010\u001b¨\u0006\u001d"}, d2 = {"Lcom/deepseek/chat/ui/components/textfield/CustomEditText;", "Landroidx/appcompat/widget/AppCompatEditText;", "Landroid/window/OnBackInvokedDispatcher;", "g", "Lvx5;", "getBackInvokedDispatcher", "()Landroid/window/OnBackInvokedDispatcher;", "backInvokedDispatcher", BuildConfig.FLAVOR, "h", "Z", "getBackToClearFocus", "()Z", "setBackToClearFocus", "(Z)V", "backToClearFocus", "Landroid/window/OnBackInvokedCallback;", "j", "getOnBackInvokedCallback", "()Landroid/window/OnBackInvokedCallback;", "onBackInvokedCallback", "Lnb5;", "getComposition", "()Lnb5;", "composition", "Lz23;", "getValue", "()Lz23;", "value", "app"}, k = 1, mv = {2, 3, 0}, xi = gk7.h)
/* loaded from: classes.dex */
public final class CustomEditText extends AppCompatEditText {
    public static final /* synthetic */ int k = 0;
    public final ey9 g;

    /* renamed from: h, reason: from kotlin metadata */
    public boolean backToClearFocus;
    public boolean i;
    public final ey9 j;

    public CustomEditText(ContextThemeWrapper contextThemeWrapper) {
        super(contextThemeWrapper, null);
        this.g = new ey9(new dj2(7, this));
        this.j = new ey9(new xa(29, this, contextThemeWrapper));
    }

    public static OnBackInvokedDispatcher b(CustomEditText customEditText) {
        if (Build.VERSION.SDK_INT >= 33) {
            return customEditText.findOnBackInvokedDispatcher();
        }
        return null;
    }

    private final OnBackInvokedDispatcher getBackInvokedDispatcher() {
        return zb.h(this.g.getValue());
    }

    private final OnBackInvokedCallback getOnBackInvokedCallback() {
        return zb.g(this.j.getValue());
    }

    public final boolean getBackToClearFocus() {
        return this.backToClearFocus;
    }

    public final nb5 getComposition() {
        Editable text = getText();
        if (text == null) {
            return null;
        }
        int composingSpanStart = BaseInputConnection.getComposingSpanStart(text);
        int composingSpanEnd = BaseInputConnection.getComposingSpanEnd(text);
        if (composingSpanStart == -1 || composingSpanEnd == -1) {
            return null;
        }
        return mv7.C(composingSpanStart, composingSpanEnd);
    }

    public final z23 getValue() {
        String str;
        Editable text = getText();
        if (text == null || (str = text.toString()) == null) {
            str = BuildConfig.FLAVOR;
        }
        return new z23(str, getComposition());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onFocusChanged(boolean z, int i, Rect rect) {
        super.onFocusChanged(z, i, rect);
        if (this.backToClearFocus && Build.VERSION.SDK_INT >= 33 && getBackInvokedDispatcher() != null) {
            if (z && !this.i) {
                OnBackInvokedDispatcher backInvokedDispatcher = getBackInvokedDispatcher();
                if (backInvokedDispatcher != null) {
                    backInvokedDispatcher.registerOnBackInvokedCallback(1000000, getOnBackInvokedCallback());
                }
                this.i = true;
                return;
            }
            if (!z && this.i) {
                OnBackInvokedDispatcher backInvokedDispatcher2 = getBackInvokedDispatcher();
                if (backInvokedDispatcher2 != null) {
                    backInvokedDispatcher2.unregisterOnBackInvokedCallback(getOnBackInvokedCallback());
                }
                this.i = false;
            }
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onKeyPreIme(int i, KeyEvent keyEvent) {
        if (this.backToClearFocus && i == 4 && keyEvent.getAction() == 1) {
            try {
                clearFocus();
                InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService(InputMethodManager.class);
                if (inputMethodManager != null) {
                    inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 2);
                }
            } catch (Exception unused) {
            }
        }
        return super.onKeyPreIme(i, keyEvent);
    }

    public final void setBackToClearFocus(boolean z) {
        this.backToClearFocus = z;
    }
}
