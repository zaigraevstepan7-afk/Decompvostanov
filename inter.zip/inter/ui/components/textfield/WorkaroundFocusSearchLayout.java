package com.deepseek.chat.ui.components.textfield;

import android.view.View;
import android.widget.FrameLayout;
import defpackage.gk7;
import kotlin.Metadata;

/* compiled from: r8-map-id-a7bb329143d8433c85843ce5c333b62cc095bf0c457acd5814e95311f0a086ce */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lcom/deepseek/chat/ui/components/textfield/WorkaroundFocusSearchLayout;", "Landroid/widget/FrameLayout;", "app"}, k = 1, mv = {2, 3, 0}, xi = gk7.h)
/* loaded from: classes.dex */
public final class WorkaroundFocusSearchLayout extends FrameLayout {
    @Override // android.view.ViewGroup, android.view.ViewParent
    public final View focusSearch(View view, int i) {
        return null;
    }
}
