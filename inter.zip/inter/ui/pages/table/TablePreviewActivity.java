package com.deepseek.chat.ui.pages.table;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import com.deepseek.chat.R;
import defpackage.cg8;
import defpackage.cn2;
import defpackage.dg8;
import defpackage.ep;
import defpackage.g43;
import defpackage.hy9;
import defpackage.ip3;
import defpackage.jd6;
import defpackage.jd8;
import defpackage.lq2;
import defpackage.m0a;
import defpackage.n0a;
import defpackage.nla;
import defpackage.op2;
import defpackage.qb9;
import defpackage.sp2;
import defpackage.ss;
import defpackage.tf5;
import defpackage.u0a;
import defpackage.vj4;
import defpackage.vm2;
import defpackage.vx5;
import defpackage.w57;
import defpackage.wv2;
import defpackage.xu8;
import defpackage.y94;
import defpackage.yg4;
import java.lang.ref.WeakReference;

/* compiled from: r8-map-id-a7bb329143d8433c85843ce5c333b62cc095bf0c457acd5814e95311f0a086ce */
/* loaded from: classes.dex */
public final class TablePreviewActivity extends ss {
    public static volatile boolean Y;
    public final vx5 B = nla.A(1, new tf5(19, this));
    public int C = -1;
    public int D = -1;
    public n0a E;
    public boolean X;

    @Override // android.app.Activity
    public final void finish() {
        boolean z;
        u0a u0aVar;
        WeakReference weakReference;
        Activity activity;
        Activity activity2;
        int i = -1;
        if (getRequestedOrientation() != -1) {
            z = true;
        } else {
            z = false;
        }
        if (z) {
            i = this.C;
        }
        xu8 y = w57.y(this);
        dg8 dg8Var = cg8.a;
        WeakReference weakReference2 = ((u0a) y.c(dg8Var.b(u0a.class), null, null)).d;
        if (weakReference2 != null && (activity2 = (Activity) weakReference2.get()) != null) {
            activity2.setRequestedOrientation(i);
        }
        if (z && this.D != this.C && (weakReference = (u0aVar = (u0a) w57.y(this).c(dg8Var.b(u0a.class), null, null)).d) != null && (activity = (Activity) weakReference.get()) != null) {
            Window window = activity.getWindow();
            int i2 = window.getAttributes().rotationAnimation;
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.rotationAnimation = 2;
            window.setAttributes(attributes);
            new Handler(Looper.getMainLooper()).postDelayed(new ep(u0aVar, i2, 3), 1500L);
        }
        Y = true;
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 34) {
            overrideActivityTransition(1, R.anim.slide_in_from_left, R.anim.slide_out_to_right);
        }
        super.finish();
        if (i3 < 34) {
            overridePendingTransition(R.anim.slide_in_from_left, R.anim.slide_out_to_right);
        }
    }

    @Override // defpackage.ss, defpackage.um2, android.app.Activity, android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        ((y94) this.B.getValue()).d(this);
    }

    @Override // defpackage.fc4, defpackage.um2, defpackage.tm2, android.app.Activity
    public final void onCreate(Bundle bundle) {
        int i;
        byte b = 0;
        ip3.a(this, new hy9(0, 0, new qb9(26)));
        super.onCreate(bundle);
        if (getResources().getConfiguration().orientation == 2) {
            i = 0;
        } else {
            i = 1;
        }
        this.C = i;
        this.D = i;
        n0a n0aVar = new n0a(this);
        if (n0aVar.canDetectOrientation()) {
            n0aVar.enable();
        }
        this.E = n0aVar;
        if (Build.VERSION.SDK_INT >= 34) {
            overrideActivityTransition(0, R.anim.slide_in_from_right, R.anim.slide_out_to_left);
            overrideActivityTransition(1, R.anim.slide_in_from_left, R.anim.slide_out_to_right);
        } else {
            overridePendingTransition(R.anim.slide_in_from_right, R.anim.slide_out_to_left);
        }
        ((y94) this.B.getValue()).d(this);
        vm2.a(this, new cn2(new m0a(this, b, b), true, -939782145));
    }

    @Override // defpackage.ss, defpackage.fc4, android.app.Activity
    public final void onDestroy() {
        n0a n0aVar = this.E;
        if (n0aVar != null) {
            n0aVar.disable();
        }
        this.E = null;
        if (this.X || isFinishing()) {
            u0a u0aVar = (u0a) w57.y(this).c(cg8.a.b(u0a.class), null, null);
            u0aVar.a.j(null);
            u0aVar.a();
        }
        super.onDestroy();
    }

    @Override // defpackage.fc4, android.app.Activity
    public final void onResume() {
        super.onResume();
        ((u0a) w57.y(this).c(cg8.a.b(u0a.class), null, null)).a();
    }

    public final void s(int i, vj4 vj4Var) {
        int i2;
        boolean z;
        TablePreviewActivity tablePreviewActivity;
        Object jd6Var;
        vj4Var.i0(-2232705);
        if (vj4Var.h(this)) {
            i2 = 4;
        } else {
            i2 = 2;
        }
        int i3 = i2 | i;
        if ((i3 & 3) != 2) {
            z = true;
        } else {
            z = false;
        }
        if (vj4Var.X(i3 & 1, z)) {
            if (sp2.d()) {
                sp2.f("com.deepseek.chat.ui.pages.table.TablePreviewActivity.FitSystemBarColor (TablePreviewActivity.kt:179)");
            }
            View view = (View) vj4Var.j(AndroidCompositionLocals_androidKt.f);
            boolean a = g43.a(((g43) vj4Var.j(lq2.a)).a, vj4Var);
            int i4 = ((Configuration) vj4Var.j(AndroidCompositionLocals_androidKt.a)).uiMode;
            Boolean valueOf = Boolean.valueOf(a);
            Window window = getWindow();
            Integer valueOf2 = Integer.valueOf(i4);
            boolean h = vj4Var.h(this) | vj4Var.h(view) | vj4Var.g(a);
            Object S = vj4Var.S();
            if (!h && S != op2.a) {
                jd6Var = S;
                tablePreviewActivity = this;
            } else {
                tablePreviewActivity = this;
                jd6Var = new jd6(tablePreviewActivity, view, a, null, 1);
                vj4Var.q0(jd6Var);
            }
            wv2.v(valueOf, window, valueOf2, (yg4) jd6Var, vj4Var);
            if (sp2.d()) {
                sp2.e();
            }
        } else {
            tablePreviewActivity = this;
            vj4Var.a0();
        }
        jd8 v = vj4Var.v();
        if (v != null) {
            v.d = new m0a(tablePreviewActivity, i);
        }
    }
}
