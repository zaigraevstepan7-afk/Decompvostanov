package com.deepseek.chat.ui.pages.root.mermaid.render;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.View;
import android.webkit.WebView;
import com.tencent.mm.opensdk.modelmsg.WXVideoFileObject;
import defpackage.ak6;
import defpackage.bk6;
import defpackage.gk7;
import defpackage.md6;
import defpackage.oca;
import defpackage.zl2;
import kotlin.Metadata;

/* compiled from: r8-map-id-a7bb329143d8433c85843ce5c333b62cc095bf0c457acd5814e95311f0a086ce */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, d2 = {"Lcom/deepseek/chat/ui/pages/root/mermaid/render/MermaidGeneratorWebView;", "Landroid/webkit/WebView;", "bk6", "app"}, k = 1, mv = {2, 3, 0}, xi = gk7.h)
/* loaded from: classes.dex */
public final class MermaidGeneratorWebView extends WebView {
    public static final /* synthetic */ int c = 0;
    public zl2 a;
    public final zl2 b;

    public MermaidGeneratorWebView(Context context) {
        super(context);
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        int i = displayMetrics.widthPixels;
        int round = Math.round(displayMetrics.density * 352.0f);
        this.b = md6.v();
        getSettings().setJavaScriptEnabled(true);
        getSettings().setDomStorageEnabled(true);
        getSettings().setBuiltInZoomControls(true);
        getSettings().setDisplayZoomControls(false);
        getSettings().setTextZoom(100);
        addJavascriptInterface(new bk6(this), "AndroidBridge");
        measure(View.MeasureSpec.makeMeasureSpec(i, WXVideoFileObject.FILE_SIZE_LIMIT), View.MeasureSpec.makeMeasureSpec(round, WXVideoFileObject.FILE_SIZE_LIMIT));
        layout(0, 0, getMeasuredWidth(), getMeasuredHeight());
        setWebViewClient(new ak6(this, 0));
        oca.c(this, "file:///android_asset/generator.html");
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0091, code lost:
    
        if (r9 != r5) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0093, code lost:
    
        return r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0054, code lost:
    
        if (r6.b.v(r0) == r5) goto L25;
     */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0039  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object a(java.lang.String r7, java.lang.String r8, defpackage.tv2 r9) {
        /*
            r6 = this;
            boolean r0 = r9 instanceof defpackage.ck6
            if (r0 == 0) goto L13
            r0 = r9
            ck6 r0 = (defpackage.ck6) r0
            int r1 = r0.h
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.h = r1
            goto L18
        L13:
            ck6 r0 = new ck6
            r0.<init>(r6, r9)
        L18:
            java.lang.Object r9 = r0.f
            int r1 = r0.h
            r2 = 2
            r3 = 1
            r4 = 0
            vw2 r5 = defpackage.vw2.a
            if (r1 == 0) goto L39
            if (r1 == r3) goto L31
            if (r1 != r2) goto L2b
            defpackage.vt7.y(r9)
            goto L94
        L2b:
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.sg0.k(r6)
            return r4
        L31:
            java.lang.String r8 = r0.e
            java.lang.String r7 = r0.d
            defpackage.vt7.y(r9)
            goto L57
        L39:
            defpackage.vt7.y(r9)
            zl2 r9 = r6.a
            if (r9 == 0) goto L48
            fl6 r6 = new fl6
            java.lang.String r7 = "RE_ENTRY"
            r6.<init>(r7)
            return r6
        L48:
            r0.d = r7
            r0.e = r8
            r0.h = r3
            zl2 r9 = r6.b
            java.lang.Object r9 = r9.v(r0)
            if (r9 != r5) goto L57
            goto L93
        L57:
            zl2 r9 = defpackage.md6.v()
            r6.a = r9
            java.lang.String r7 = org.json.JSONObject.quote(r7)
            java.lang.String r8 = org.json.JSONObject.quote(r8)
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r3 = "\n            if (window.generateMermaid) {\n                window.generateMermaid("
            r1.<init>(r3)
            r1.append(r7)
            java.lang.String r7 = ", "
            r1.append(r7)
            r1.append(r8)
            java.lang.String r7 = ");\n            }\n        "
            r1.append(r7)
            java.lang.String r7 = r1.toString()
            java.lang.String r7 = defpackage.mt9.D(r7)
            r6.evaluateJavascript(r7, r4)
            r0.d = r4
            r0.e = r4
            r0.h = r2
            java.lang.Object r9 = r9.v(r0)
            if (r9 != r5) goto L94
        L93:
            return r5
        L94:
            il6 r9 = (defpackage.il6) r9
            r6.a = r4
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.deepseek.chat.ui.pages.root.mermaid.render.MermaidGeneratorWebView.a(java.lang.String, java.lang.String, tv2):java.lang.Object");
    }

    /* JADX WARN: Code restructure failed: missing block: B:26:0x0046, code lost:
    
        if (r9 == r5) goto L26;
     */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0039  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0023  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object b(java.lang.String r7, java.lang.String r8, defpackage.tv2 r9) {
        /*
            r6 = this;
            boolean r0 = r9 instanceof defpackage.dk6
            if (r0 == 0) goto L13
            r0 = r9
            dk6 r0 = (defpackage.dk6) r0
            int r1 = r0.h
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.h = r1
            goto L18
        L13:
            dk6 r0 = new dk6
            r0.<init>(r6, r9)
        L18:
            java.lang.Object r9 = r0.f
            int r1 = r0.h
            r2 = 2
            r3 = 1
            r4 = 0
            vw2 r5 = defpackage.vw2.a
            if (r1 == 0) goto L39
            if (r1 == r3) goto L31
            if (r1 != r2) goto L2b
            defpackage.vt7.y(r9)
            return r9
        L2b:
            java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
            defpackage.sg0.k(r6)
            return r4
        L31:
            java.lang.String r8 = r0.e
            java.lang.String r7 = r0.d
            defpackage.vt7.y(r9)
            goto L49
        L39:
            defpackage.vt7.y(r9)
            r0.d = r7
            r0.e = r8
            r0.h = r3
            java.lang.Object r9 = r6.a(r7, r8, r0)
            if (r9 != r5) goto L49
            goto L6c
        L49:
            il6 r9 = (defpackage.il6) r9
            boolean r1 = r9 instanceof defpackage.fl6
            if (r1 == 0) goto L6e
            r1 = r9
            fl6 r1 = (defpackage.fl6) r1
            java.lang.String r1 = r1.a
            java.lang.String r3 = "RENDER_FAILED"
            boolean r1 = defpackage.zc5.b(r1, r3)
            if (r1 == 0) goto L6e
            java.lang.String r7 = defpackage.wv2.k0(r7)
            r0.d = r4
            r0.e = r4
            r0.h = r2
            java.lang.Object r6 = r6.a(r7, r8, r0)
            if (r6 != r5) goto L6d
        L6c:
            return r5
        L6d:
            return r6
        L6e:
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.deepseek.chat.ui.pages.root.mermaid.render.MermaidGeneratorWebView.b(java.lang.String, java.lang.String, tv2):java.lang.Object");
    }
}
