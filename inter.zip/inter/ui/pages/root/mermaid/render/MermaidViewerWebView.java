package com.deepseek.chat.ui.pages.root.mermaid.render;

import android.webkit.WebView;
import defpackage.gk7;
import defpackage.mt9;
import defpackage.zl2;
import kotlin.Metadata;
import org.json.JSONObject;

/* compiled from: r8-map-id-a7bb329143d8433c85843ce5c333b62cc095bf0c457acd5814e95311f0a086ce */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0002¨\u0006\u0003"}, d2 = {"Lcom/deepseek/chat/ui/pages/root/mermaid/render/MermaidViewerWebView;", "Landroid/webkit/WebView;", "pl6", "app"}, k = 1, mv = {2, 3, 0}, xi = gk7.h)
/* loaded from: classes.dex */
public final class MermaidViewerWebView extends WebView {
    public final zl2 a;
    public zl2 b;
    public final zl2 c;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public MermaidViewerWebView(android.content.Context r5, java.lang.String r6) {
        /*
            r4 = this;
            java.lang.String r0 = "dark"
            boolean r6 = defpackage.zc5.b(r6, r0)
            if (r6 == 0) goto L11
            pv2 r6 = new pv2
            r0 = 2131755293(0x7f10011d, float:1.9141461E38)
            r6.<init>(r5, r0)
            goto L19
        L11:
            pv2 r6 = new pv2
            r0 = 2131755294(0x7f10011e, float:1.9141463E38)
            r6.<init>(r5, r0)
        L19:
            r4.<init>(r6)
            android.content.res.Resources r5 = r5.getResources()
            android.util.DisplayMetrics r5 = r5.getDisplayMetrics()
            int r6 = r5.widthPixels
            int r5 = r5.heightPixels
            zl2 r0 = defpackage.md6.v()
            r4.a = r0
            zl2 r0 = defpackage.md6.v()
            r4.b = r0
            zl2 r0 = defpackage.md6.v()
            r4.c = r0
            android.webkit.WebSettings r0 = r4.getSettings()
            r1 = 1
            r0.setJavaScriptEnabled(r1)
            android.webkit.WebSettings r0 = r4.getSettings()
            r0.setDomStorageEnabled(r1)
            android.webkit.WebSettings r0 = r4.getSettings()
            r0.setBuiltInZoomControls(r1)
            android.webkit.WebSettings r0 = r4.getSettings()
            r2 = 0
            r0.setDisplayZoomControls(r2)
            android.webkit.WebSettings r0 = r4.getSettings()
            r3 = 100
            r0.setTextZoom(r3)
            pl6 r0 = new pl6
            r0.<init>(r4)
            java.lang.String r3 = "NativeBridge"
            r4.addJavascriptInterface(r0, r3)
            r0 = 1073741824(0x40000000, float:2.0)
            int r6 = android.view.View.MeasureSpec.makeMeasureSpec(r6, r0)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r0)
            r4.measure(r6, r5)
            int r5 = r4.getMeasuredWidth()
            int r6 = r4.getMeasuredHeight()
            r4.layout(r2, r2, r5, r6)
            ak6 r5 = new ak6
            r5.<init>(r4, r1)
            r4.setWebViewClient(r5)
            java.lang.String r5 = "file:///android_asset/viewer.html"
            defpackage.oca.c(r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.deepseek.chat.ui.pages.root.mermaid.render.MermaidViewerWebView.<init>(android.content.Context, java.lang.String):void");
    }

    public final void a(String str) {
        evaluateJavascript(mt9.D("\n        if (window.JSBridge && window.JSBridge.requestRenderMermaid) {\n            window.JSBridge.requestRenderMermaid(" + JSONObject.quote(str) + ", 0);\n        }\n        "), null);
    }

    /* JADX WARN: Code restructure failed: missing block: B:30:0x00d0, code lost:
    
        if (r14 != r11) goto L50;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x00d2, code lost:
    
        return r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x009c, code lost:
    
        if (r14 == r11) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x006f, code lost:
    
        if (r14 != r11) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x005b, code lost:
    
        if (r12.a.v(r0) == r11) goto L49;
     */
    /* JADX WARN: Removed duplicated region for block: B:47:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x002b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object b(java.lang.String r13, defpackage.tv2 r14) {
        /*
            Method dump skipped, instructions count: 222
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.deepseek.chat.ui.pages.root.mermaid.render.MermaidViewerWebView.b(java.lang.String, tv2):java.lang.Object");
    }
}
